public class Square implements BasicShape {
    private double length;

    Square(double length){
        this.length = length;
    }

    public double area(){
        return length * 2;
    }
    public double perimeter(){
        return length;
    }
}
