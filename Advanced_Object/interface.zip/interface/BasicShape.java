public interface BasicShape {
        public double area();
        public double perimeter();
}