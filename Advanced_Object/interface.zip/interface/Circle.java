public class Circle implements BasicShape{
    private double radius;

    Circle(int radius) {
        this.radius = radius;
    }

    public double area(){
        return radius * 2;
    }
    public double perimeter(){
        return radius * 2;
    }
}
