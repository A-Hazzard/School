
public class Test{
    public static void main(String[] args) {

        BasicShape SH[] ={
            new Square(3),
            new Square(4),
            new Circle(5),
            new Circle(4)    
        };
        
        for(BasicShape shapes: SH) {
            System.out.println(shapes.area());
        }




    }

}
